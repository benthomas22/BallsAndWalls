package game;

import java.awt.Color;

public interface ColorUnlock {
	Color getColor(int score);
}
